Just a simple text file for tests
